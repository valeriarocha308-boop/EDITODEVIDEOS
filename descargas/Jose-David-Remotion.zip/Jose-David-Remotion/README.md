# José David — IVA y movilidad eléctrica

Edición vertical 1080 × 1920, 30 fps, 98,6667 segundos (2960 fotogramas).

La composición conserva de principio a fin la imagen y todas las palabras de JOSE.mov; no se recortaron pausas ni se cambió la velocidad. Se transcodificó el original HEVC a H.264 para compatibilidad. Hay reencuadres, B-roll ilustrativo, subtítulos blancos, cifras, efectos de sonido y dos pasajes breves en blanco y negro con filtro tonal suave de voz. La voz fue normalizada; no se sintetizó ni reemplazó.

## Abrir

Con Node.js instalado:

```
npm ci
npm run dev
```

Abrir la composición `Jose-David-IVA` en la URL que muestra Remotion Studio.

Para exportar, usar el botón Render del Studio, formato H.264 (MP4), 1080 × 1920, 30 fps. También está disponible:

```
npx remotion render src/index.ts Jose-David-IVA Jose-David-IVA.mp4 --codec=h264
```

## Archivos

- `src/Root.tsx`: montaje y subtítulos por palabra editables en Studio.
- `src/Visuals.tsx`: reencuadres, cifras, títulos y B-roll.
- `public/jose.mp4`: transcodificación completa del original; su audio está silenciado en el montaje.
- `public/voice.m4a`: voz original procesada, misma duración y sincronía.
- `public/jose-subtitulos.srt`: subtítulos completos.
- `public/broll/sources.json`: fuentes y autores del material Pexels; imágenes ilustrativas sin ubicación colombiana atribuida.
- `public/sfx/`: efectos de Remotion Media.
- `public/fonts/`: Montserrat Black de Google Fonts.

## Nota editorial

El audio difiere del guion aportado. Dice literalmente «cada vez que reemplazamos un vehículo eléctrico por un vehículo de combustión», invirtiendo la relación del argumento escrito. Este lapsus y «a diciembre de 31» se conservaron en audio y subtítulos por la instrucción de no quitar ninguna palabra. La gráfica del déficit muestra «más de $4 billones», tal como se pronuncia. No se realizó una verificación externa de las afirmaciones fiscales.
