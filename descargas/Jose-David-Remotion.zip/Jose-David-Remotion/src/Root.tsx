import React from 'react';
import {AbsoluteFill,Composition,Sequence,staticFile,useVideoConfig} from 'remotion';
import {Audio} from '@remotion/media';
import {Speaker,Intro,Broll,Stat,TopMessage} from './Visuals';
import {BasicCaptions} from './basic-captions';
import './style.css';
export const JoseEdit = () => { const {fps}=useVideoConfig(); return <AbsoluteFill style={{background:'#061320',fontFamily:'Montserrat,Arial,sans-serif'}}>
<Sequence name="Original completo · sin quitar palabras" durationInFrames={2960} premountFor={fps}>
<Speaker/>
<Audio name="Voz original completa" src={staticFile('voice.m4a')} premountFor={fps}/>
<Sequence name="Título y firma" durationInFrames={145} premountFor={fps}><Intro/></Sequence>
<Sequence name="Recarga eléctrica" from={3.8*fps} durationInFrames={2.8*fps} premountFor={fps}><Broll src="broll/ev-charge.mp4" label="Movilidad eléctrica"/></Sequence>
<Sequence name="IVA propuesto" from={6.7*fps} durationInFrames={3*fps} premountFor={fps}><Stat kind="tax"/></Sequence>
<Sequence name="Gasolina" from={32.8*fps} durationInFrames={66} premountFor={fps}><Broll src="broll/fuel-nozzle.mp4" label="Combustibles"/></Sequence>
<Sequence name="Déficit FEPC" from={36.5*fps} durationInFrames={4*fps} premountFor={fps}><Stat kind="deficit"/></Sequence>
<Sequence name="Tráfico" from={45.7*fps} durationInFrames={3*fps} premountFor={fps}><Broll src="broll/traffic.mp4" label="Consumo de gasolina"/></Sequence>
<Sequence name="Sustitución por eléctrico" from={48.7*fps} durationInFrames={3.5*fps} premountFor={fps}><Broll src="broll/ev-car.mp4" label="Vehículos eléctricos"/></Sequence>
<Sequence name="Efecto sobre subsidios" from={53*fps} durationInFrames={4.3*fps} premountFor={fps}><Stat kind="balance"/></Sequence>
<Sequence name="Electrificación" from={64*fps} durationInFrames={4.8*fps} premountFor={fps}><Broll src="broll/ev-charge.mp4" label="Movilidad eléctrica"/></Sequence>
<Sequence name="Mirada fiscal a largo plazo" from={74*fps} durationInFrames={5*fps} premountFor={fps}><Stat kind="future"/></Sequence>
<Sequence name="La pregunta fiscal" from={26*fps} durationInFrames={6.2*fps} premountFor={fps}><TopMessage eyebrow="LA PREGUNTA">¿RECAUDAR HOY<br/>O AHORRAR MAÑANA?</TopMessage></Sequence>
<Sequence name="Solicitud al Congreso" from={89.4*fps} durationInFrames={9.2*fps} premountFor={fps}><TopMessage eyebrow="JOSÉ DAVID NAME CARDOZO">UN LLAMADO<br/>AL CONGRESO</TopMessage></Sequence>
<div data-caption="white"><BasicCaptions name="Subtítulos blancos" premountFor={fps} width={960} combineTokensWithinMilliseconds={900} style={{position:'absolute',left:60,top:1250}} captions={[
  {
    "text": " El",
    "startMs": 740,
    "endMs": 860,
    "timestampMs": 800,
    "confidence": 0.3424493670463562
  },
  {
    "text": " gobierno",
    "startMs": 860,
    "endMs": 1080,
    "timestampMs": 970,
    "confidence": 0.7018998861312866
  },
  {
    "text": " quiere",
    "startMs": 1080,
    "endMs": 1480,
    "timestampMs": 1280,
    "confidence": 0.9620555639266968,
    "pageBreakAfter": true
  },
  {
    "text": " aumentar",
    "startMs": 1480,
    "endMs": 1880,
    "timestampMs": 1680,
    "confidence": 0.9874124526977539
  },
  {
    "text": " los",
    "startMs": 1880,
    "endMs": 2140,
    "timestampMs": 2010,
    "confidence": 0.9717179536819458
  },
  {
    "text": " impuestos,",
    "startMs": 2140,
    "endMs": 2620,
    "timestampMs": 2380,
    "confidence": 0.9966312050819397,
    "pageBreakAfter": true
  },
  {
    "text": " el",
    "startMs": 3000,
    "endMs": 3220,
    "timestampMs": 3110,
    "confidence": 0.8831257224082947
  },
  {
    "text": " IVA,",
    "startMs": 3220,
    "endMs": 3600,
    "timestampMs": 3410,
    "confidence": 0.9795008301734924,
    "pageBreakAfter": true
  },
  {
    "text": " a",
    "startMs": 4020,
    "endMs": 4080,
    "timestampMs": 4050,
    "confidence": 0.9440874457359314
  },
  {
    "text": " los",
    "startMs": 4080,
    "endMs": 4220,
    "timestampMs": 4150,
    "confidence": 0.9973921775817871
  },
  {
    "text": " carros",
    "startMs": 4220,
    "endMs": 4500,
    "timestampMs": 4360,
    "confidence": 0.9737683832645416,
    "pageBreakAfter": true
  },
  {
    "text": " eléctricos",
    "startMs": 4500,
    "endMs": 5100,
    "timestampMs": 4800,
    "confidence": 0.9891226768493653
  },
  {
    "text": " e",
    "startMs": 5100,
    "endMs": 5320,
    "timestampMs": 5210,
    "confidence": 0.9625292420387268
  },
  {
    "text": " híbridos",
    "startMs": 5320,
    "endMs": 5700,
    "timestampMs": 5510,
    "confidence": 0.9837209433317184,
    "pageBreakAfter": true
  },
  {
    "text": " del",
    "startMs": 5700,
    "endMs": 6300,
    "timestampMs": 6000,
    "confidence": 0.7996476292610168
  },
  {
    "text": " 5",
    "startMs": 6300,
    "endMs": 6640,
    "timestampMs": 6470,
    "confidence": 0.9779052138328552
  },
  {
    "text": "%",
    "startMs": 6640,
    "endMs": 7220,
    "timestampMs": 6930,
    "confidence": 0.8745133280754089,
    "pageBreakAfter": true
  },
  {
    "text": " al",
    "startMs": 7220,
    "endMs": 8000,
    "timestampMs": 7610,
    "confidence": 0.9866523146629333
  },
  {
    "text": " 19%.",
    "startMs": 8000,
    "endMs": 9460,
    "timestampMs": 8730,
    "confidence": 0.9735271334648132,
    "pageBreakAfter": true
  },
  {
    "text": " Hoy",
    "startMs": 9860,
    "endMs": 10260,
    "timestampMs": 10060,
    "confidence": 0.9929918050765991
  },
  {
    "text": " quiero",
    "startMs": 10260,
    "endMs": 10440,
    "timestampMs": 10350,
    "confidence": 0.9844374656677246
  },
  {
    "text": " hablarles",
    "startMs": 10440,
    "endMs": 11060,
    "timestampMs": 10750,
    "confidence": 0.9894888401031494,
    "pageBreakAfter": true
  },
  {
    "text": " de",
    "startMs": 11060,
    "endMs": 11840,
    "timestampMs": 11450,
    "confidence": 0.9760915637016296
  },
  {
    "text": " la",
    "startMs": 11840,
    "endMs": 11960,
    "timestampMs": 11900,
    "confidence": 0.9930516481399536
  },
  {
    "text": " Ley",
    "startMs": 11960,
    "endMs": 12120,
    "timestampMs": 12040,
    "confidence": 0.5358380079269409,
    "pageBreakAfter": true
  },
  {
    "text": " de",
    "startMs": 12120,
    "endMs": 12300,
    "timestampMs": 12210,
    "confidence": 0.933862030506134
  },
  {
    "text": " Rescate",
    "startMs": 12300,
    "endMs": 12980,
    "timestampMs": 12640,
    "confidence": 0.9246679147084554
  },
  {
    "text": " Económico,",
    "startMs": 12980,
    "endMs": 14120,
    "timestampMs": 13550,
    "confidence": 0.9686259627342224,
    "pageBreakAfter": true
  },
  {
    "text": " la",
    "startMs": 15060,
    "endMs": 15180,
    "timestampMs": 15120,
    "confidence": 0.9566398859024048
  },
  {
    "text": " nueva",
    "startMs": 15180,
    "endMs": 15340,
    "timestampMs": 15260,
    "confidence": 0.988567590713501
  },
  {
    "text": " reforma",
    "startMs": 15340,
    "endMs": 15940,
    "timestampMs": 15640,
    "confidence": 0.94284987449646,
    "pageBreakAfter": true
  },
  {
    "text": " tributaria",
    "startMs": 15940,
    "endMs": 16440,
    "timestampMs": 16190,
    "confidence": 0.9887797037760416
  },
  {
    "text": " que",
    "startMs": 16440,
    "endMs": 16620,
    "timestampMs": 16530,
    "confidence": 0.9829732179641724
  },
  {
    "text": " presentó",
    "startMs": 16620,
    "endMs": 17020,
    "timestampMs": 16820,
    "confidence": 0.874273955821991,
    "pageBreakAfter": true
  },
  {
    "text": " el",
    "startMs": 17020,
    "endMs": 17080,
    "timestampMs": 17050,
    "confidence": 0.9797424674034119
  },
  {
    "text": " gobierno,",
    "startMs": 17080,
    "endMs": 17400,
    "timestampMs": 17240,
    "confidence": 0.8802687525749207,
    "pageBreakAfter": true
  },
  {
    "text": " especialmente",
    "startMs": 17960,
    "endMs": 18540,
    "timestampMs": 18250,
    "confidence": 0.9930114150047302
  },
  {
    "text": " sobre",
    "startMs": 18540,
    "endMs": 19860,
    "timestampMs": 19200,
    "confidence": 0.9111840128898621
  },
  {
    "text": " cargar",
    "startMs": 19860,
    "endMs": 20860,
    "timestampMs": 20360,
    "confidence": 0.9845448434352875,
    "pageBreakAfter": true
  },
  {
    "text": " con",
    "startMs": 20860,
    "endMs": 21340,
    "timestampMs": 21100,
    "confidence": 0.977044403553009
  },
  {
    "text": " más",
    "startMs": 21340,
    "endMs": 21580,
    "timestampMs": 21460,
    "confidence": 0.9813305735588074
  },
  {
    "text": " impuestos",
    "startMs": 21580,
    "endMs": 22080,
    "timestampMs": 21830,
    "confidence": 0.9970828592777252,
    "pageBreakAfter": true
  },
  {
    "text": " a",
    "startMs": 22080,
    "endMs": 22520,
    "timestampMs": 22300,
    "confidence": 0.9762819409370422
  },
  {
    "text": " los",
    "startMs": 22520,
    "endMs": 22640,
    "timestampMs": 22580,
    "confidence": 0.9989689588546753
  },
  {
    "text": " carros",
    "startMs": 22640,
    "endMs": 22980,
    "timestampMs": 22810,
    "confidence": 0.9957409203052521,
    "pageBreakAfter": true
  },
  {
    "text": " híbridos",
    "startMs": 22980,
    "endMs": 23540,
    "timestampMs": 23260,
    "confidence": 0.9956019818782806
  },
  {
    "text": " y",
    "startMs": 23540,
    "endMs": 23840,
    "timestampMs": 23690,
    "confidence": 0.9913638830184937
  },
  {
    "text": " a",
    "startMs": 23840,
    "endMs": 23900,
    "timestampMs": 23870,
    "confidence": 0.915697455406189,
    "pageBreakAfter": true
  },
  {
    "text": " los",
    "startMs": 23900,
    "endMs": 24040,
    "timestampMs": 23970,
    "confidence": 0.9982447624206543
  },
  {
    "text": " carros",
    "startMs": 24040,
    "endMs": 24380,
    "timestampMs": 24210,
    "confidence": 0.996292769908905
  },
  {
    "text": " eléctricos.",
    "startMs": 24380,
    "endMs": 25100,
    "timestampMs": 24740,
    "confidence": 0.9973023056983947,
    "pageBreakAfter": true
  },
  {
    "text": " Pero",
    "startMs": 25100,
    "endMs": 25680,
    "timestampMs": 25390,
    "confidence": 0.5340956449508667
  },
  {
    "text": " hay",
    "startMs": 25680,
    "endMs": 25760,
    "timestampMs": 25720,
    "confidence": 0.936981737613678
  },
  {
    "text": " una",
    "startMs": 25760,
    "endMs": 25880,
    "timestampMs": 25820,
    "confidence": 0.9892789721488953,
    "pageBreakAfter": true
  },
  {
    "text": " pregunta",
    "startMs": 25880,
    "endMs": 26180,
    "timestampMs": 26030,
    "confidence": 0.9917563199996948
  },
  {
    "text": " que",
    "startMs": 26180,
    "endMs": 26380,
    "timestampMs": 26280,
    "confidence": 0.9831314086914062
  },
  {
    "text": " debemos",
    "startMs": 26380,
    "endMs": 26620,
    "timestampMs": 26500,
    "confidence": 0.9345308542251587,
    "pageBreakAfter": true
  },
  {
    "text": " hacernos,",
    "startMs": 26620,
    "endMs": 27180,
    "timestampMs": 26900,
    "confidence": 0.7418162326018015,
    "pageBreakAfter": true
  },
  {
    "text": " queremos",
    "startMs": 27640,
    "endMs": 28020,
    "timestampMs": 27830,
    "confidence": 0.7430422902107239
  },
  {
    "text": " recaudar",
    "startMs": 28020,
    "endMs": 28640,
    "timestampMs": 28330,
    "confidence": 0.914501965045929
  },
  {
    "text": " más",
    "startMs": 28640,
    "endMs": 29140,
    "timestampMs": 28890,
    "confidence": 0.675490140914917,
    "pageBreakAfter": true
  },
  {
    "text": " impuestos",
    "startMs": 29140,
    "endMs": 29580,
    "timestampMs": 29360,
    "confidence": 0.9958051443099976
  },
  {
    "text": " hoy",
    "startMs": 29580,
    "endMs": 30040,
    "timestampMs": 29810,
    "confidence": 0.9804719090461731
  },
  {
    "text": " o",
    "startMs": 30040,
    "endMs": 30680,
    "timestampMs": 30360,
    "confidence": 0.6735511422157288,
    "pageBreakAfter": true
  },
  {
    "text": " ahorrar",
    "startMs": 30680,
    "endMs": 31160,
    "timestampMs": 30920,
    "confidence": 0.9458191096782684
  },
  {
    "text": " en",
    "startMs": 31160,
    "endMs": 31720,
    "timestampMs": 31440,
    "confidence": 0.9384191036224365
  },
  {
    "text": " el",
    "startMs": 31720,
    "endMs": 31840,
    "timestampMs": 31780,
    "confidence": 0.9784432649612427,
    "pageBreakAfter": true
  },
  {
    "text": " futuro?",
    "startMs": 31840,
    "endMs": 32120,
    "timestampMs": 31980,
    "confidence": 0.9975553154945374,
    "pageBreakAfter": true
  },
  {
    "text": " Solamente",
    "startMs": 32780,
    "endMs": 33360,
    "timestampMs": 33070,
    "confidence": 0.9126717746257782
  },
  {
    "text": " en",
    "startMs": 33360,
    "endMs": 33580,
    "timestampMs": 33470,
    "confidence": 0.9196984171867371
  },
  {
    "text": " el",
    "startMs": 33580,
    "endMs": 33680,
    "timestampMs": 33630,
    "confidence": 0.965707004070282,
    "pageBreakAfter": true
  },
  {
    "text": " primer",
    "startMs": 33680,
    "endMs": 33860,
    "timestampMs": 33770,
    "confidence": 0.9859282970428467
  },
  {
    "text": " semestre",
    "startMs": 33860,
    "endMs": 34400,
    "timestampMs": 34130,
    "confidence": 0.9906392395496368
  },
  {
    "text": " del",
    "startMs": 34400,
    "endMs": 34920,
    "timestampMs": 34660,
    "confidence": 0.6760144829750061,
    "pageBreakAfter": true
  },
  {
    "text": " 2026",
    "startMs": 34920,
    "endMs": 35660,
    "timestampMs": 35290,
    "confidence": 0.7704126536846161
  },
  {
    "text": " este",
    "startMs": 35660,
    "endMs": 36440,
    "timestampMs": 36050,
    "confidence": 0.5657331347465515
  },
  {
    "text": " fondo",
    "startMs": 36440,
    "endMs": 36780,
    "timestampMs": 36610,
    "confidence": 0.9790409803390503,
    "pageBreakAfter": true
  },
  {
    "text": " tiene",
    "startMs": 36780,
    "endMs": 37180,
    "timestampMs": 36980,
    "confidence": 0.9903780221939087
  },
  {
    "text": " un",
    "startMs": 37180,
    "endMs": 37320,
    "timestampMs": 37250,
    "confidence": 0.9855303764343262
  },
  {
    "text": " déficit",
    "startMs": 37320,
    "endMs": 37820,
    "timestampMs": 37570,
    "confidence": 0.9656184315681458,
    "pageBreakAfter": true
  },
  {
    "text": " de",
    "startMs": 37820,
    "endMs": 38100,
    "timestampMs": 37960,
    "confidence": 0.9885885715484619
  },
  {
    "text": " más",
    "startMs": 38100,
    "endMs": 38280,
    "timestampMs": 38190,
    "confidence": 0.9391680955886841
  },
  {
    "text": " de",
    "startMs": 38280,
    "endMs": 38440,
    "timestampMs": 38360,
    "confidence": 0.9938176274299622,
    "pageBreakAfter": true
  },
  {
    "text": " 4",
    "startMs": 38440,
    "endMs": 38780,
    "timestampMs": 38610,
    "confidence": 0.9271060228347778
  },
  {
    "text": " billones",
    "startMs": 38780,
    "endMs": 39340,
    "timestampMs": 39060,
    "confidence": 0.9130429625511169
  },
  {
    "text": " de",
    "startMs": 39340,
    "endMs": 39520,
    "timestampMs": 39430,
    "confidence": 0.9780036211013794,
    "pageBreakAfter": true
  },
  {
    "text": " pesos,",
    "startMs": 39520,
    "endMs": 39760,
    "timestampMs": 39640,
    "confidence": 0.9942469596862793,
    "pageBreakAfter": true
  },
  {
    "text": " lo",
    "startMs": 40080,
    "endMs": 40280,
    "timestampMs": 40180,
    "confidence": 0.9687702655792236
  },
  {
    "text": " que",
    "startMs": 40280,
    "endMs": 40400,
    "timestampMs": 40340,
    "confidence": 0.992701530456543
  },
  {
    "text": " quiere",
    "startMs": 40400,
    "endMs": 40560,
    "timestampMs": 40480,
    "confidence": 0.9807902574539185,
    "pageBreakAfter": true
  },
  {
    "text": " decir",
    "startMs": 40560,
    "endMs": 40920,
    "timestampMs": 40740,
    "confidence": 0.9952848553657532
  },
  {
    "text": " que",
    "startMs": 40920,
    "endMs": 41480,
    "timestampMs": 41200,
    "confidence": 0.6977749466896057
  },
  {
    "text": " a",
    "startMs": 41480,
    "endMs": 41540,
    "timestampMs": 41510,
    "confidence": 0.8079291582107544,
    "pageBreakAfter": true
  },
  {
    "text": " diciembre",
    "startMs": 41540,
    "endMs": 41840,
    "timestampMs": 41690,
    "confidence": 0.9851395189762115
  },
  {
    "text": " de",
    "startMs": 41840,
    "endMs": 41940,
    "timestampMs": 41890,
    "confidence": 0.3647947907447815
  },
  {
    "text": " 31",
    "startMs": 41940,
    "endMs": 42380,
    "timestampMs": 42160,
    "confidence": 0.8176328539848328,
    "pageBreakAfter": true
  },
  {
    "text": " tendrá",
    "startMs": 42380,
    "endMs": 43020,
    "timestampMs": 42700,
    "confidence": 0.7599627375602722
  },
  {
    "text": " un",
    "startMs": 43020,
    "endMs": 43120,
    "timestampMs": 43070,
    "confidence": 0.9752792716026306
  },
  {
    "text": " déficit",
    "startMs": 43120,
    "endMs": 43620,
    "timestampMs": 43370,
    "confidence": 0.9967145721117655,
    "pageBreakAfter": true
  },
  {
    "text": " de",
    "startMs": 43620,
    "endMs": 43900,
    "timestampMs": 43760,
    "confidence": 0.9676328897476196
  },
  {
    "text": " más",
    "startMs": 43900,
    "endMs": 44020,
    "timestampMs": 43960,
    "confidence": 0.9773303270339966
  },
  {
    "text": " de",
    "startMs": 44020,
    "endMs": 44180,
    "timestampMs": 44100,
    "confidence": 0.9774158596992493,
    "pageBreakAfter": true
  },
  {
    "text": " 8",
    "startMs": 44180,
    "endMs": 44520,
    "timestampMs": 44350,
    "confidence": 0.9572227597236633
  },
  {
    "text": " billones",
    "startMs": 44520,
    "endMs": 45040,
    "timestampMs": 44780,
    "confidence": 0.9697477221488953
  },
  {
    "text": " de",
    "startMs": 45040,
    "endMs": 45220,
    "timestampMs": 45130,
    "confidence": 0.9685168266296387,
    "pageBreakAfter": true
  },
  {
    "text": " pesos.",
    "startMs": 45220,
    "endMs": 45500,
    "timestampMs": 45360,
    "confidence": 0.9881855249404907,
    "pageBreakAfter": true
  },
  {
    "text": " Y",
    "startMs": 45680,
    "endMs": 45880,
    "timestampMs": 45780,
    "confidence": 0.926800012588501
  },
  {
    "text": " aquí",
    "startMs": 45880,
    "endMs": 46060,
    "timestampMs": 45970,
    "confidence": 0.9628098607063293
  },
  {
    "text": " existe",
    "startMs": 46060,
    "endMs": 46440,
    "timestampMs": 46250,
    "confidence": 0.9874169826507568,
    "pageBreakAfter": true
  },
  {
    "text": " la",
    "startMs": 46440,
    "endMs": 46580,
    "timestampMs": 46510,
    "confidence": 0.9692273139953613
  },
  {
    "text": " paradoja,",
    "startMs": 46580,
    "endMs": 47060,
    "timestampMs": 46820,
    "confidence": 0.974177340666453,
    "pageBreakAfter": true
  },
  {
    "text": " cada",
    "startMs": 47320,
    "endMs": 47460,
    "timestampMs": 47390,
    "confidence": 0.9904149770736694
  },
  {
    "text": " vez",
    "startMs": 47460,
    "endMs": 47640,
    "timestampMs": 47550,
    "confidence": 0.9992110729217529
  },
  {
    "text": " que",
    "startMs": 47640,
    "endMs": 47760,
    "timestampMs": 47700,
    "confidence": 0.9964509010314941,
    "pageBreakAfter": true
  },
  {
    "text": " reemplazamos",
    "startMs": 47760,
    "endMs": 48260,
    "timestampMs": 48010,
    "confidence": 0.950921505689621
  },
  {
    "text": " un",
    "startMs": 48260,
    "endMs": 48500,
    "timestampMs": 48380,
    "confidence": 0.9873080849647522
  },
  {
    "text": " vehículo",
    "startMs": 48500,
    "endMs": 48880,
    "timestampMs": 48690,
    "confidence": 0.9908105134963989,
    "pageBreakAfter": true
  },
  {
    "text": " eléctrico",
    "startMs": 48880,
    "endMs": 49360,
    "timestampMs": 49120,
    "confidence": 0.9946516454219818
  },
  {
    "text": " por",
    "startMs": 49360,
    "endMs": 50140,
    "timestampMs": 49750,
    "confidence": 0.922876238822937
  },
  {
    "text": " un",
    "startMs": 50140,
    "endMs": 50340,
    "timestampMs": 50240,
    "confidence": 0.8987675309181213,
    "pageBreakAfter": true
  },
  {
    "text": " vehículo",
    "startMs": 50340,
    "endMs": 51020,
    "timestampMs": 50680,
    "confidence": 0.9962676763534546
  },
  {
    "text": " de",
    "startMs": 51020,
    "endMs": 51200,
    "timestampMs": 51110,
    "confidence": 0.43470194935798645
  },
  {
    "text": " combustión",
    "startMs": 51200,
    "endMs": 51720,
    "timestampMs": 51460,
    "confidence": 0.9120386838912964,
    "pageBreakAfter": true
  },
  {
    "text": " ahorramos",
    "startMs": 51720,
    "endMs": 52680,
    "timestampMs": 52200,
    "confidence": 0.8808586299419403
  },
  {
    "text": " dinero",
    "startMs": 52680,
    "endMs": 53080,
    "timestampMs": 52880,
    "confidence": 0.978371798992157
  },
  {
    "text": " al",
    "startMs": 53080,
    "endMs": 53460,
    "timestampMs": 53270,
    "confidence": 0.9753963947296143,
    "pageBreakAfter": true
  },
  {
    "text": " estado.",
    "startMs": 53460,
    "endMs": 53800,
    "timestampMs": 53630,
    "confidence": 0.37836652994155884,
    "pageBreakAfter": true
  },
  {
    "text": " El",
    "startMs": 54120,
    "endMs": 54220,
    "timestampMs": 54170,
    "confidence": 0.915518045425415
  },
  {
    "text": " estado",
    "startMs": 54220,
    "endMs": 54560,
    "timestampMs": 54390,
    "confidence": 0.9173545241355896
  },
  {
    "text": " tiene",
    "startMs": 54560,
    "endMs": 55080,
    "timestampMs": 54820,
    "confidence": 0.9875981211662292,
    "pageBreakAfter": true
  },
  {
    "text": " que",
    "startMs": 55080,
    "endMs": 55240,
    "timestampMs": 55160,
    "confidence": 0.9955171942710876
  },
  {
    "text": " poner",
    "startMs": 55240,
    "endMs": 55500,
    "timestampMs": 55370,
    "confidence": 0.9970858693122864
  },
  {
    "text": " menos",
    "startMs": 55500,
    "endMs": 55900,
    "timestampMs": 55700,
    "confidence": 0.9841841459274292,
    "pageBreakAfter": true
  },
  {
    "text": " subsidios",
    "startMs": 55900,
    "endMs": 56460,
    "timestampMs": 56180,
    "confidence": 0.8908740878105164
  },
  {
    "text": " a",
    "startMs": 56460,
    "endMs": 56760,
    "timestampMs": 56610,
    "confidence": 0.9499373435974121
  },
  {
    "text": " ese",
    "startMs": 56760,
    "endMs": 56940,
    "timestampMs": 56850,
    "confidence": 0.9029621481895447,
    "pageBreakAfter": true
  },
  {
    "text": " fondo.",
    "startMs": 56940,
    "endMs": 57280,
    "timestampMs": 57110,
    "confidence": 0.9863227605819702,
    "pageBreakAfter": true
  },
  {
    "text": " Entonces",
    "startMs": 57720,
    "endMs": 58060,
    "timestampMs": 57890,
    "confidence": 0.9476405382156372
  },
  {
    "text": " la",
    "startMs": 58060,
    "endMs": 58260,
    "timestampMs": 58160,
    "confidence": 0.8389304876327515
  },
  {
    "text": " pregunta",
    "startMs": 58260,
    "endMs": 58520,
    "timestampMs": 58390,
    "confidence": 0.9980183839797974,
    "pageBreakAfter": true
  },
  {
    "text": " clave",
    "startMs": 58520,
    "endMs": 58960,
    "timestampMs": 58740,
    "confidence": 0.9983481168746948
  },
  {
    "text": " es",
    "startMs": 58960,
    "endMs": 59260,
    "timestampMs": 59110,
    "confidence": 0.9939292669296265
  },
  {
    "text": " ¿por",
    "startMs": 59260,
    "endMs": 59660,
    "timestampMs": 59460,
    "confidence": 0.4772012382745743,
    "pageBreakAfter": true
  },
  {
    "text": " qué",
    "startMs": 59660,
    "endMs": 59940,
    "timestampMs": 59800,
    "confidence": 0.9452831149101257
  },
  {
    "text": " ponerle",
    "startMs": 59940,
    "endMs": 60620,
    "timestampMs": 60280,
    "confidence": 0.9921143651008606
  },
  {
    "text": " más",
    "startMs": 60620,
    "endMs": 60880,
    "timestampMs": 60750,
    "confidence": 0.9882106781005859,
    "pageBreakAfter": true
  },
  {
    "text": " impuestos",
    "startMs": 60880,
    "endMs": 61500,
    "timestampMs": 61190,
    "confidence": 0.9934185147285461
  },
  {
    "text": " a",
    "startMs": 61500,
    "endMs": 61800,
    "timestampMs": 61650,
    "confidence": 0.987727165222168
  },
  {
    "text": " los",
    "startMs": 61800,
    "endMs": 61920,
    "timestampMs": 61860,
    "confidence": 0.9958677291870117,
    "pageBreakAfter": true
  },
  {
    "text": " carros",
    "startMs": 61920,
    "endMs": 62200,
    "timestampMs": 62060,
    "confidence": 0.9904355108737946
  },
  {
    "text": " eléctricos",
    "startMs": 62200,
    "endMs": 62860,
    "timestampMs": 62530,
    "confidence": 0.9879157543182373
  },
  {
    "text": " cuando",
    "startMs": 62860,
    "endMs": 63260,
    "timestampMs": 63060,
    "confidence": 0.8855931162834167,
    "pageBreakAfter": true
  },
  {
    "text": " en",
    "startMs": 63260,
    "endMs": 63400,
    "timestampMs": 63330,
    "confidence": 0.9631598591804504
  },
  {
    "text": " el",
    "startMs": 63400,
    "endMs": 63520,
    "timestampMs": 63460,
    "confidence": 0.9895776510238647
  },
  {
    "text": " futuro",
    "startMs": 63520,
    "endMs": 63820,
    "timestampMs": 63670,
    "confidence": 0.9993436932563782,
    "pageBreakAfter": true
  },
  {
    "text": " nos",
    "startMs": 63820,
    "endMs": 64340,
    "timestampMs": 64080,
    "confidence": 0.9914535284042358
  },
  {
    "text": " va",
    "startMs": 64340,
    "endMs": 64540,
    "timestampMs": 64440,
    "confidence": 0.925457239151001
  },
  {
    "text": " a",
    "startMs": 64540,
    "endMs": 64620,
    "timestampMs": 64580,
    "confidence": 0.9343225955963135,
    "pageBreakAfter": true
  },
  {
    "text": " ayudar",
    "startMs": 64620,
    "endMs": 64860,
    "timestampMs": 64740,
    "confidence": 0.9954191446304321
  },
  {
    "text": " a",
    "startMs": 64860,
    "endMs": 65400,
    "timestampMs": 65130,
    "confidence": 0.9748293161392212
  },
  {
    "text": " reducir",
    "startMs": 65400,
    "endMs": 65980,
    "timestampMs": 65690,
    "confidence": 0.9961837530136108,
    "pageBreakAfter": true
  },
  {
    "text": " el",
    "startMs": 65980,
    "endMs": 66480,
    "timestampMs": 66230,
    "confidence": 0.9938925504684448
  },
  {
    "text": " déficit",
    "startMs": 66480,
    "endMs": 67000,
    "timestampMs": 66740,
    "confidence": 0.9903983871142069
  },
  {
    "text": " que",
    "startMs": 67000,
    "endMs": 67280,
    "timestampMs": 67140,
    "confidence": 0.9672671556472778,
    "pageBreakAfter": true
  },
  {
    "text": " hay",
    "startMs": 67280,
    "endMs": 67440,
    "timestampMs": 67360,
    "confidence": 0.9943980574607849
  },
  {
    "text": " en",
    "startMs": 67440,
    "endMs": 67560,
    "timestampMs": 67500,
    "confidence": 0.9940125346183777
  },
  {
    "text": " el",
    "startMs": 67560,
    "endMs": 67680,
    "timestampMs": 67620,
    "confidence": 0.9971445202827454,
    "pageBreakAfter": true
  },
  {
    "text": " fondo",
    "startMs": 67680,
    "endMs": 67960,
    "timestampMs": 67820,
    "confidence": 0.995196521282196
  },
  {
    "text": " de",
    "startMs": 67960,
    "endMs": 68400,
    "timestampMs": 68180,
    "confidence": 0.9915415644645691
  },
  {
    "text": " los",
    "startMs": 68400,
    "endMs": 68500,
    "timestampMs": 68450,
    "confidence": 0.996826171875,
    "pageBreakAfter": true
  },
  {
    "text": " combustibles?",
    "startMs": 68500,
    "endMs": 69020,
    "timestampMs": 68760,
    "confidence": 0.9953087866306305,
    "pageBreakAfter": true
  },
  {
    "text": " No",
    "startMs": 69600,
    "endMs": 69860,
    "timestampMs": 69730,
    "confidence": 0.9200001358985901
  },
  {
    "text": " podemos",
    "startMs": 69860,
    "endMs": 70220,
    "timestampMs": 70040,
    "confidence": 0.9964292645454407
  },
  {
    "text": " mirar",
    "startMs": 70220,
    "endMs": 70700,
    "timestampMs": 70460,
    "confidence": 0.9968320429325104,
    "pageBreakAfter": true
  },
  {
    "text": " el",
    "startMs": 70700,
    "endMs": 70980,
    "timestampMs": 70840,
    "confidence": 0.9895732998847961
  },
  {
    "text": " recaudo",
    "startMs": 70980,
    "endMs": 71520,
    "timestampMs": 71250,
    "confidence": 0.9851292371749878
  },
  {
    "text": " de",
    "startMs": 71520,
    "endMs": 72300,
    "timestampMs": 71910,
    "confidence": 0.99615877866745,
    "pageBreakAfter": true
  },
  {
    "text": " impuestos",
    "startMs": 72300,
    "endMs": 72720,
    "timestampMs": 72510,
    "confidence": 0.989792674779892
  },
  {
    "text": " a",
    "startMs": 72720,
    "endMs": 72960,
    "timestampMs": 72840,
    "confidence": 0.9978364109992981
  },
  {
    "text": " corto",
    "startMs": 72960,
    "endMs": 73280,
    "timestampMs": 73120,
    "confidence": 0.9944040775299072,
    "pageBreakAfter": true
  },
  {
    "text": " plazo.",
    "startMs": 73280,
    "endMs": 73660,
    "timestampMs": 73470,
    "confidence": 0.9967556595802307,
    "pageBreakAfter": true
  },
  {
    "text": " Tenemos",
    "startMs": 74020,
    "endMs": 74400,
    "timestampMs": 74210,
    "confidence": 0.9958784580230713
  },
  {
    "text": " que",
    "startMs": 74400,
    "endMs": 74720,
    "timestampMs": 74560,
    "confidence": 0.9990999698638916
  },
  {
    "text": " mirar",
    "startMs": 74720,
    "endMs": 75460,
    "timestampMs": 75090,
    "confidence": 0.9946062564849854,
    "pageBreakAfter": true
  },
  {
    "text": " el",
    "startMs": 75460,
    "endMs": 75740,
    "timestampMs": 75600,
    "confidence": 0.9967401623725891
  },
  {
    "text": " impacto",
    "startMs": 75740,
    "endMs": 76160,
    "timestampMs": 75950,
    "confidence": 0.9980870485305786
  },
  {
    "text": " fiscal",
    "startMs": 76160,
    "endMs": 76700,
    "timestampMs": 76430,
    "confidence": 0.9973316192626953,
    "pageBreakAfter": true
  },
  {
    "text": " a",
    "startMs": 76700,
    "endMs": 77240,
    "timestampMs": 76970,
    "confidence": 0.9777969717979431
  },
  {
    "text": " largo",
    "startMs": 77240,
    "endMs": 77500,
    "timestampMs": 77370,
    "confidence": 0.9994858503341675
  },
  {
    "text": " plazo",
    "startMs": 77500,
    "endMs": 77920,
    "timestampMs": 77710,
    "confidence": 0.9988188743591309,
    "pageBreakAfter": true
  },
  {
    "text": " de",
    "startMs": 77920,
    "endMs": 78240,
    "timestampMs": 78080,
    "confidence": 0.5835316181182861
  },
  {
    "text": " este",
    "startMs": 78240,
    "endMs": 78560,
    "timestampMs": 78400,
    "confidence": 0.9441073536872864
  },
  {
    "text": " fondo,",
    "startMs": 78560,
    "endMs": 78920,
    "timestampMs": 78740,
    "confidence": 0.8200556635856628,
    "pageBreakAfter": true
  },
  {
    "text": " porque",
    "startMs": 79160,
    "endMs": 79360,
    "timestampMs": 79260,
    "confidence": 0.9618764519691467
  },
  {
    "text": " una",
    "startMs": 79360,
    "endMs": 79540,
    "timestampMs": 79450,
    "confidence": 0.9930707812309265
  },
  {
    "text": " buena",
    "startMs": 79540,
    "endMs": 79800,
    "timestampMs": 79670,
    "confidence": 0.8832761645317078,
    "pageBreakAfter": true
  },
  {
    "text": " reforma",
    "startMs": 79800,
    "endMs": 80300,
    "timestampMs": 80050,
    "confidence": 0.9757704436779022
  },
  {
    "text": " tributaria",
    "startMs": 80300,
    "endMs": 80880,
    "timestampMs": 80590,
    "confidence": 0.9856808185577393
  },
  {
    "text": " no",
    "startMs": 80880,
    "endMs": 81440,
    "timestampMs": 81160,
    "confidence": 0.9521716237068176,
    "pageBreakAfter": true
  },
  {
    "text": " es",
    "startMs": 81440,
    "endMs": 81760,
    "timestampMs": 81600,
    "confidence": 0.9969484210014343
  },
  {
    "text": " cuánto",
    "startMs": 81760,
    "endMs": 82440,
    "timestampMs": 82100,
    "confidence": 0.7839930355548859
  },
  {
    "text": " podemos",
    "startMs": 82440,
    "endMs": 82700,
    "timestampMs": 82570,
    "confidence": 0.9828709363937378,
    "pageBreakAfter": true
  },
  {
    "text": " recaudar",
    "startMs": 82700,
    "endMs": 83320,
    "timestampMs": 83010,
    "confidence": 0.9978829423586527
  },
  {
    "text": " hoy,",
    "startMs": 83320,
    "endMs": 83580,
    "timestampMs": 83450,
    "confidence": 0.9936081171035767,
    "pageBreakAfter": true
  },
  {
    "text": " es",
    "startMs": 84000,
    "endMs": 84200,
    "timestampMs": 84100,
    "confidence": 0.9840399622917175
  },
  {
    "text": " cuánto",
    "startMs": 84200,
    "endMs": 85160,
    "timestampMs": 84680,
    "confidence": 0.9870527386665344
  },
  {
    "text": " puede",
    "startMs": 85160,
    "endMs": 85400,
    "timestampMs": 85280,
    "confidence": 0.9799762964248657,
    "pageBreakAfter": true
  },
  {
    "text": " tener",
    "startMs": 85400,
    "endMs": 85800,
    "timestampMs": 85600,
    "confidence": 0.9852670431137085
  },
  {
    "text": " de",
    "startMs": 85800,
    "endMs": 86060,
    "timestampMs": 85930,
    "confidence": 0.9791983366012573
  },
  {
    "text": " sostenibilidad",
    "startMs": 86060,
    "endMs": 86660,
    "timestampMs": 86360,
    "confidence": 0.9559232195218405,
    "pageBreakAfter": true
  },
  {
    "text": " fiscal",
    "startMs": 86660,
    "endMs": 87380,
    "timestampMs": 87020,
    "confidence": 0.9912264943122864
  },
  {
    "text": " el",
    "startMs": 87380,
    "endMs": 87800,
    "timestampMs": 87590,
    "confidence": 0.9714075326919556
  },
  {
    "text": " país",
    "startMs": 87800,
    "endMs": 88100,
    "timestampMs": 87950,
    "confidence": 0.9831212759017944,
    "pageBreakAfter": true
  },
  {
    "text": " a",
    "startMs": 88100,
    "endMs": 88420,
    "timestampMs": 88260,
    "confidence": 0.9848034381866455
  },
  {
    "text": " futuro.",
    "startMs": 88420,
    "endMs": 88760,
    "timestampMs": 88590,
    "confidence": 0.9974023103713989,
    "pageBreakAfter": true
  },
  {
    "text": " Le",
    "startMs": 89420,
    "endMs": 89600,
    "timestampMs": 89510,
    "confidence": 0.6385189890861511
  },
  {
    "text": " solicito",
    "startMs": 89600,
    "endMs": 90160,
    "timestampMs": 89880,
    "confidence": 0.993779331445694
  },
  {
    "text": " a",
    "startMs": 90160,
    "endMs": 90280,
    "timestampMs": 90220,
    "confidence": 0.9920279383659363,
    "pageBreakAfter": true
  },
  {
    "text": " las",
    "startMs": 90280,
    "endMs": 90500,
    "timestampMs": 90390,
    "confidence": 0.9920593500137329
  },
  {
    "text": " comisiones",
    "startMs": 90500,
    "endMs": 91220,
    "timestampMs": 90860,
    "confidence": 0.9143014152844747
  },
  {
    "text": " económicas",
    "startMs": 91220,
    "endMs": 91740,
    "timestampMs": 91480,
    "confidence": 0.9858614504337311,
    "pageBreakAfter": true
  },
  {
    "text": " del",
    "startMs": 91740,
    "endMs": 91860,
    "timestampMs": 91800,
    "confidence": 0.9805306196212769
  },
  {
    "text": " Congreso",
    "startMs": 91860,
    "endMs": 92340,
    "timestampMs": 92100,
    "confidence": 0.9053966999053955
  },
  {
    "text": " mirar",
    "startMs": 92340,
    "endMs": 93180,
    "timestampMs": 92760,
    "confidence": 0.7471779435873032,
    "pageBreakAfter": true
  },
  {
    "text": " con",
    "startMs": 93180,
    "endMs": 93300,
    "timestampMs": 93240,
    "confidence": 0.9796538949012756
  },
  {
    "text": " mucho",
    "startMs": 93300,
    "endMs": 93620,
    "timestampMs": 93460,
    "confidence": 0.9975109100341797
  },
  {
    "text": " cuidado",
    "startMs": 93620,
    "endMs": 94020,
    "timestampMs": 93820,
    "confidence": 0.9983956217765808,
    "pageBreakAfter": true
  },
  {
    "text": " ponerle",
    "startMs": 94020,
    "endMs": 94900,
    "timestampMs": 94460,
    "confidence": 0.8404293358325958
  },
  {
    "text": " más",
    "startMs": 94900,
    "endMs": 95140,
    "timestampMs": 95020,
    "confidence": 0.9920876622200012
  },
  {
    "text": " impuestos",
    "startMs": 95140,
    "endMs": 95700,
    "timestampMs": 95420,
    "confidence": 0.9939484596252441,
    "pageBreakAfter": true
  },
  {
    "text": " a",
    "startMs": 95700,
    "endMs": 96200,
    "timestampMs": 95950,
    "confidence": 0.9849237203598022
  },
  {
    "text": " los",
    "startMs": 96200,
    "endMs": 96340,
    "timestampMs": 96270,
    "confidence": 0.9979165196418762
  },
  {
    "text": " carros",
    "startMs": 96340,
    "endMs": 96740,
    "timestampMs": 96540,
    "confidence": 0.9813114106655121,
    "pageBreakAfter": true
  },
  {
    "text": " eléctricos",
    "startMs": 96740,
    "endMs": 97580,
    "timestampMs": 97160,
    "confidence": 0.988430631160736
  },
  {
    "text": " e",
    "startMs": 97580,
    "endMs": 97700,
    "timestampMs": 97640,
    "confidence": 0.9424004554748535
  },
  {
    "text": " híbridos.",
    "startMs": 97700,
    "endMs": 98140,
    "timestampMs": 97920,
    "confidence": 0.928445115685463,
    "pageBreakAfter": true
  }
]}/></div>
</Sequence>
<Audio name="Entrada de cifra" from={6.7*fps} src={staticFile('sfx/switch.wav')} volume={.22} premountFor={fps}/>
<Audio name="Transición eléctrica" from={3.8*fps} src={staticFile('sfx/whoosh.wav')} volume={.10} premountFor={fps}/>
<Audio name="Dato fiscal" from={36.5*fps} src={staticFile('sfx/switch.wav')} volume={.20} premountFor={fps}/>
<Audio name="Cambio de plano" from={48.7*fps} src={staticFile('sfx/whoosh.wav')} volume={.10} premountFor={fps}/>
<Audio name="Cierre" from={74*fps} src={staticFile('sfx/ding.wav')} volume={.07} premountFor={fps}/>
</AbsoluteFill>};
export const RemotionRoot = () => <Composition id="Jose-David-IVA" component={JoseEdit} durationInFrames={2960} fps={30} width={1080} height={1920}/>;
